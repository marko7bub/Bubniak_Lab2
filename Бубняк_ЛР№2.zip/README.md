# Movie map generator

This module is made for creating an HTML map of said location with markers that represent movies shot nearby. The user has to put in a year and the site's coordinates and the program will generate an HTML map of this location with up to 10 markers reprsenting the movies that have been shot there that year.

## Usage

```bash
Please enter a year you would like to have a map for: 2012
Please enter your location (format: lat, long): 40.7410861, -73.9896297241625
Map is generating...
Please wait...
Finished. Please have look at the map 2012_movies_map.html
```