import folium
import geopy
from geopy.geocoders import Nominatim
from geopy.extra.rate_limiter import RateLimiter

year = input("Please enter a year you would like to have a map for: ")
coordinates = input("Please enter your location (format: lat, long): ")

print('Map is generating...')
print('Please wait...')

map = folium.Map(location=[float(coordinates.split(', ')[0]),
                           float(coordinates.split(', ')[1])], zoom_start=16)

geolocator = Nominatim(user_agent="main.py")
reverse = RateLimiter(geolocator.reverse, min_delay_seconds=1)
location = geolocator.geocode(coordinates, addressdetails=True)

city = location.raw['address']['city']

f = open('new_locations.list')
movies_list = f.readlines()
counter = 0

for movie in movies_list:
    if '(' + year + ')' in movie:
        if city in movie:
            folium.Marker(location=[float(coordinates.split(', ')[0]),
                                    float(coordinates.split(', ')[1])],
                          popup=movie,
                          icon=folium.Icon()).add_to(map)
            counter += 1
            coordinates = str(float(coordinates.split(', ')[0]) + 0.001) + ', ' + str(float(coordinates.split(', ')[1]) + 0.001)
            if counter == 10:
                break

map.save(year + '_movies_map.html')
print('Finished. Please have look at the map ' + year + '_movies_map.html')
